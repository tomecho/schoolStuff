# Once you have written your version of the shell, write a design document that documents your design choices here.
