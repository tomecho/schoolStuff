#include "ProducerConsumer.h"
	
//TODO: add BoundedBuffer, locks and any global variables here 


void InitProducerConsumer(int p, int c, int psleep, int csleep, int items){
	//TODO: constructor to initialize variables declared
		//also see instruction for implementation
}


void *producer(void* threadID){
	//TODO: producer thread, see instruction for implementation
}

void *consumer(void* threadID){
	//TODO: consumer thread, see instruction for implementation
}