#include "BoundedBuffer.h"

BoundedBuffer::BoundedBuffer(int N){
  //TODO: constructor to initiliaze all the varibales declared in BoundedBuffer.h 
  buff = new int[N];
  size = N;
  count = 0;
  pnt = 0;
}
void BoundedBuffer::append(int data){
  //TODO: append a data item to the circular buffer
  pthread_mutex_lock(&ap_lock); //single appender at one time
    if(count==size)
      pthread_cond_wait(&empty,&ap_lock); //wait for something to be removed
    buff[pnt] = data; //write the thing
    pnt = (pnt+1) % size; //this will set it to pnt+1 or zero effectivly
    count++; //increment count
    pthread_cond_signal(&full); //let the remove thread knows its cool and can remove something now
  pthread_mutex_unlock(&ap_lock); //let other write operations happen
}

int BoundedBuffer::remove(){
  //TODO: remove and return a data item from the circular buffer
  pthread_mutex_lock(&rm_lock); //only one remove at a time
    if(count==0) //if its empty
      pthread_cond_wait(&full,&rm_lock); //wait for something to be appended
    int item = buff[(pnt-count) % size]; //remove it
    count--; //there is one less item now
    pthread_cond_signal(&empty); //let the remove thread knows its cool and can add something now
  pthread_mutex_unlock(&rm_lock); //now the other removers can start
  return item; //return our item
}

bool BoundedBuffer::isEmpty(){
  //TODO: check is the buffer is empty
  return count==0;
}
