# Once you have written your version of the shell, write a design document that documents your design choices here.

#  Describe your design and design decisions here




# Describe the behavior of your program for the three input scenarios here.






# Briefly describe you test case and testing efforts here




# Briefly describe your debugging efforts here