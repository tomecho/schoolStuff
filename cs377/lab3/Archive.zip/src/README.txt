# Once you have written your version of the file system, write a design document that documents your design choices here.

# Describe whether this assignment is individual or group work. List group member names and email addresses here. 

my partner was Rafael Bielech

#  Describe your design and design decisions here




# Briefly describe you test cases and testing efforts here




# Briefly describe your debugging efforts here

