# Startup Product: Client Side

This repository will hold the *client side* of your product. The client
side of your product runs in the browser.
[![Issue Count](https://codeclimate.com/github/AtomicGeoAssassins/team-project-client-template/badges/issue_count.svg)](https://codeclimate.com/github/AtomicGeoAssassins/team-project-client-template)
[![Code Climate](https://codeclimate.com/github/AtomicGeoAssassins/team-project-client-template/badges/gpa.svg)](https://codeclimate.com/github/AtomicGeoAssassins/team-project-client-template)
