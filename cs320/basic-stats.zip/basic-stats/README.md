#Basic Statistics

A Java-based implementation for descriptive statistics. This
implementation is merely intended to be used in the CS520/620 course.

How to build: TBD

How to run: TBD

Features: TBD
