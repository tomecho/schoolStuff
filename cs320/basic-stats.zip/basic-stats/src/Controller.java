
public interface Controller {

	public void addModel(Model model);
	public void updateModels(Double num);

}
